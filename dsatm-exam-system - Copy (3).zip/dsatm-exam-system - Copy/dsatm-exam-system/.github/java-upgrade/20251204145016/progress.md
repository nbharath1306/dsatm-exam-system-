# Upgrade Progress

  ### ❗ Generate Upgrade Plan
  
  <details>
      <summary>[ click to toggle details ]</summary>
  
  #### Errors
  - "GitHub Copilot app modernization - upgrade for Java" and its tools are only available for signed-in GitHub Copilot users.. Please sign in with a GitHub account first.
  </details>